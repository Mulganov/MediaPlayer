package com.android.mediacodec

import android.media.MediaCodec
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Size

class MainActivity : AppCompatActivity(){
    val mime = "video/avc"

    val mediaCodec = MediaCodec.createEncoderByType(mime)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var heightsRange = mediaCodec.codecInfo
            .getCapabilitiesForType(mime).videoCapabilities.supportedHeights
        var widthsRange = mediaCodec.codecInfo
            .getCapabilitiesForType(mime).videoCapabilities.supportedWidths

        mediaCodec.codecInfo.getCapabilitiesForType(mime).videoCapabilities.widthAlignment
        mediaCodec.codecInfo.getCapabilitiesForType(mime).videoCapabilities.widthAlignment

        Log.i("qwer", "lower: ${widthsRange.lower} ${heightsRange.lower}")
        Log.i("qwer", "upper: ${widthsRange.upper} ${heightsRange.upper}")
        Log.i("qwer", "Alignment: ${mediaCodec.codecInfo.getCapabilitiesForType(mime).videoCapabilities.widthAlignment} ${mediaCodec.codecInfo.getCapabilitiesForType(mime).videoCapabilities.heightAlignment}")


        Log.i("qwer","---------------")


        Log.i("qwer","result: ${getBestSupportedResolution(Size(3840, 3820))}")
//        Log.i("qwer","result: ${getBestSupportedResolution(Size(96, 96))}")
//        Log.i("qwer","result: ${getBestSupportedResolution(Size(240, 320))}")
//        Log.i("qwer","result: ${getBestSupportedResolution(Size(540, 320))}")
//        Log.i("qwer","result: ${getBestSupportedResolution(Size(1200, 320))}")
//        Log.i("qwer","result: ${getBestSupportedResolution(Size(1200, 3220))}")
    }

    fun getBestSupportedResolution(
        preferredResolution: Size,
        mime: String = "video/avc"
    ): Size {
        val mTag: String = "VideoUtil"
        val mediaCodec = MediaCodec.createEncoderByType(mime)

        if (isSizeSupported(preferredResolution))
            return preferredResolution

        var size = preferredResolution

        val heightsRange = mediaCodec.codecInfo
            .getCapabilitiesForType(mime).videoCapabilities.supportedHeights
        val widthsRange = mediaCodec.codecInfo
            .getCapabilitiesForType(mime).videoCapabilities.supportedWidths

        val alignW = mediaCodec.codecInfo.getCapabilitiesForType(mime).videoCapabilities.widthAlignment
        val alignH = mediaCodec.codecInfo.getCapabilitiesForType(mime).videoCapabilities.widthAlignment

        var width = size.width.toFloat()
        var height = size.height.toFloat()

        //  Меняем размеры Size под стандарт --> lower <= size <= upper
        if ( size.width <  widthsRange.lower || size.height <  heightsRange.lower ){
            val kw = widthsRange.lower / size.width.toFloat()
            val kh = heightsRange.lower / size.height.toFloat()

            val kMax = if (kw > kh) kw else kh

            width = (width * kMax)
            height = (height * kMax)
        }else
        if (
            widthsRange.lower <= size.width && size.width <= widthsRange.upper
            &&
            heightsRange.lower <= size.height && size.height <= heightsRange.upper
        ){
            if (width > widthsRange.upper)
                width -= (width % alignW)*2
        }else
        if ( size.width >  widthsRange.upper || size.height >  heightsRange.upper ){
            val kw = widthsRange.upper / size.width.toFloat()
            val kh = heightsRange.upper / size.height.toFloat()

            val kMin = if (kw < kh) kw else kh

            width = (width * kMin)
            height = (height * kMin)
        }


        // проверка на Alignment
        if (height.toInt() % alignH != 0){
            height += height % alignH
        }
        if (width.toInt() % alignW != 0){
            width += width % alignW
        }


        val w: Float = width / height
        val h: Float = 1f

        // если есть какой то трабла с размерами то постепенно уменьшать их
        while ( !isSizeSupported(width.toInt(), height.toInt()) || (height < heightsRange.lower || width < widthsRange.lower)){
            width -= w
            height -= h
        }

        return Size(width.toInt(), height.toInt())
    }

    private fun isSizeSupported(size: Size): Boolean {
        return isSizeSupported(size.width, size.height)
    }

    private fun isSizeSupported(width: Int, height: Int): Boolean {
        return mediaCodec.codecInfo.getCapabilitiesForType(mime)
            .videoCapabilities.isSizeSupported(
                width,
                height
            )
    }


}