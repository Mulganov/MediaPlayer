package com.videffects.sample.interfaces

interface OnSelectShaderListener {

    /**
     * Argument should implement ShaderInterface of Filter
     */
    fun onSelectShader(shader: Any)
}