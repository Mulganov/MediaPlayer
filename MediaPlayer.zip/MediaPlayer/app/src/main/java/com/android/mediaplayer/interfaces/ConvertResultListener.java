package com.android.mediaplayer.interfaces;

public interface ConvertResultListener {

    void onSuccess();

    void onFail();
}
